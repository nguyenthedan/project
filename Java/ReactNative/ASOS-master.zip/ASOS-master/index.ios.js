/**
 * ASOS React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import {AppRegistry} from 'react-native';
import setup from './src/setup';

AppRegistry.registerComponent('Asos',  setup)

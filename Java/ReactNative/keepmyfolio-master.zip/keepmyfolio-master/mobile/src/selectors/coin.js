// @flow

// import { createSelector } from 'reselect';

// _getHolding(): number {
//   if (this.props.entities == null) {
//     return 0;
//   }

//   const totalAmount: number = this.props.entities.reduce(
//     (prev, current) => prev + parseFloat(current.amountOfCoin),
//     0,
//   );

//   return totalAmount;
// }

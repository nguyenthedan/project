## Running

### Configure Env

For changing environment to `production` or `staging`

```
yarn configure staging
```

### IOS

```
yarn start
```

```
react-native run-ios
```

### Android

```
yarn start
```

```
react-native run-android
```
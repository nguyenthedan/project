// @flow

export default {
  environment: 'production',
  baseUrl: 'https://v0idk7zieb.execute-api.us-east-1.amazonaws.com/staging/graphql'
}

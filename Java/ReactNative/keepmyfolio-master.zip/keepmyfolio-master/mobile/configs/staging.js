// @flow

export default {
  environment: 'staging',
  baseUrl: 'http://192.168.56.1:3000/graphql'
}

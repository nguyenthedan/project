// flow-typed signature: 41a21b97ad4a7c01c4caf3a8b9382354
// flow-typed version: b43dff3e0e/invariant_v2.x.x/flow_>=v0.33.x

declare module invariant {
  declare var exports: (condition: boolean, message: string) => void;
}

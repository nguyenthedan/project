# DEPLOY

## Staging

`yarn deploy`

## Production

`yarn deploy --stage production`

# LOGS

```
serverless logs -f graphql
```
import * as NoteActions from './note';

export const ActionCreators = Object.assign({},
    NoteActions
);

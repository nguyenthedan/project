/* @flow */

export const ADD_NOTE:string = "ADD_NOTE";
export const EDIT_NOTE:string = "EDIT_NOTE";
export const DELETE_NOTE:string = "DELETE_NOTE";

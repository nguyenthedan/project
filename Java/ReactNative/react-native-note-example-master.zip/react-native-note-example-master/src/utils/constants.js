/* @flow */

export const APP_NAME: string = 'Renote';

export const LANG: string = 'en';

export const TIME_ZONE: string = 'en-EN';

export const GMAPS_API_KEY: string = 'AIzaSyBXNDm0zCJz86EuiFmdjmrGeTlgK9WJ3T4';

export const ANDROID_VERSIONS: Object = {
  LOLLIPOP: 21
};